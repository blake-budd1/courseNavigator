To run and interact with these programs, ensure that the 'announcments.csv' file is in the same directory as both the 'DesignA.py' and 'DesignB.py'.

To start a new instance of CourseNavigator run the following commands from your terminal:
1. Make sure the terminal is in this directory (cd CourseNavigatorFinal)
2. To run either design
    To run DesignA:
        python DesignA.py
    To run DesignB:
        python DesignB.py

